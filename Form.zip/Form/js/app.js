// variables
const password = document.querySelector("#password");
const passwordConfirm = document.querySelector("#passwordConfirm");
const passwordImg = document.querySelector("#passwordImg");
const passwordImg2 = document.querySelector("#passwordImg2");
const name = document.querySelector("#name");
const btn = document.querySelector(".btn");
const email = document.querySelector("#email");
const budge = document.querySelectorAll(".budge");
let number = 0;
let numberConfirm = 0;

// eventListeners
eventListeners();
function eventListeners() {
    // show password
    passwordImg.addEventListener("click", showPassword);
    // show password confirm
    passwordImg2.addEventListener("click", showPasswordConfirm);
    // validate fields form
    btn.addEventListener("click", validateFields);
}

// functions

// show password
function showPassword() {
    if (number == 0) {
        passwordImg.src = "./images/eye-view.svg";
        password.setAttribute("type", "text");
        number++;
    } else {
        passwordImg.src = "./images/eye-close.svg";
        password.setAttribute("type", "password");
        number--;
    }
}

// show password confirm
function showPasswordConfirm() {
    if (numberConfirm == 0) {
        passwordImg2.src = "./images/eye-view.svg";
        passwordConfirm.setAttribute("type", "text");
        numberConfirm++;
    } else {
        passwordImg2.src = "./images/eye-close.svg";
        passwordConfirm.setAttribute("type", "password");
        numberConfirm--;
    }
}

// validate fields form
function validateFields(e) {
    // return false or true ?
    let numberReturn = 0;
    e.preventDefault();
    // pattern email
    const pattern = /[a-z0-9]+@+[a-z0-9]+\.+[a-z]{2,4}/g;

    // validate field name
    if (name.value.length <= 3 == true) {
        budge[0].style.display = "block";

        // 3second the display none
        setTimeout(() => {
            setTimeout(() => {
                budge[0].style.display = "none";
            }, 300);
        }, 3000);
    } else {
        numberReturn++;
    }

    // validate field email
    if (pattern.test(email.value) == false) {
        budge[1].style.display = "block";

        // 3second the display none
        setTimeout(() => {
            setTimeout(() => {
                budge[1].style.display = "none";
            }, 300);
        }, 3000);
    } else {
        numberReturn++;
    }

    // validate field password
    if (password.value.length <= 6 == true) {
        budge[2].style.display = "block";

        // 3second the display none
        setTimeout(() => {
            setTimeout(() => {
                budge[2].style.display = "none";
            }, 300);
        }, 3000);
    } else {
        numberReturn++;
    }

    // validte field passwordConfirm
    if (passwordConfirm.value.length <= 6 == true) {
        budge[3].style.display = "block";

        // 3second the display none
        setTimeout(() => {
            setTimeout(() => {
                budge[3].style.display = "none";
            }, 300);
        }, 3000);
    }

    // validate field passwordConfirm and password
    if (
        password.value.length <= 6 == false &&
        passwordConfirm.value.length <= 6 == false
    ) {
        // validate field passwordConfirm and password
        if (passwordConfirm.value != password.value) {
            budge[3].style.display = "block";

            // 3second the display none
            setTimeout(() => {
                setTimeout(() => {
                    budge[3].style.display = "none";
                }, 300);
            }, 3000);
        } else {
            numberReturn++;
        }
    }

    // validate and send data to the server
    if (numberReturn == 4) {
        swal("ثبت نام شد", "ثبت نام شما با موفقیت انجام شد.", "success");
        document.querySelector(".swal-button").innerHTML = "باشه";
    }
    numberReturn = 0;
}
